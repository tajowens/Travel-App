package com.example.android.hummingbirdtravelagency;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView textView;
    Button button;

    public MainActivity() {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SetContentView();

        final SharedPreferences sharedPref = SetContentView();
        assert sharedPref != null;
        String oldItem= sharedPref.getString("oldItem", "Hummingbird Travel Agency");

        textView.setText(oldItem);
        button.setOnClickListener(v -> {
            SharedPreferences.Editor editor = sharedPref.edit();
            editor.putString("oldItem", textView.getText().toString());
            editor.apply();
        });
    }

    private SharedPreferences SetContentView() {
        return null;
    }

}

