package com.example.android.hummingbirdtravelagency;

import android.os.Bundle;

public abstract class AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
    }
}
